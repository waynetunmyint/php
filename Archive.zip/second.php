<?php echo "before html";?>
<html>
	<head>
		<title>Second PHP Page</title>
	</head>
	<body>
		<hr>
		<?php echo "hello world";?>
		<hr>
	</body>
</html>
<?php echo "after HTML";?>

<script>
	alert('<?php echo "inside Javascript";?>');
</script>