<b>
<?php
	echo "Hello world";

?>
</b>

<hr>

<b><?php echo "hello world"; ?></b>
<h1>This is wayne's Server</h1>