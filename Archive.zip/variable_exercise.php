<?php
	// int int1;
	// int1="string";

	$variable1=3;
	echo $variable1;
	echo '<hr>';

	$variable1=3.14;
	echo $variable1;
	echo '<hr>';

	$variable1="hello";
	echo $variable1;
	echo '<hr>';

?>