<?php
	$a=3;
	$b=4;
	echo $a+$b;


	function function_name()
	{

	}


	function eat($food)
	{
		return $energy;

	}

?>